<p align="center">

[![License](https://img.shields.io/github/license/Saeidjamali/intellithing)](https://github.com/Saeidjamali/intellithing/blob/main/LICENSE)
[![Release](https://img.shields.io/github/v/release/Saeidjamali/intellithing?label=release)](https://github.com/Saeidjamali/intellithing/releases)
[![Website](https://img.shields.io/badge/website-online-800080)](https://intellithing.tech)

</p>



# intellithing

intellithing (seperate from INTELLITHING platfrom) is an opensource project started by frasturated data scientists.

intellithing is an opensource library to reduce the amount of coding required for a successful finetuning of Large Language Models. 
# Install
pip install intellithing
