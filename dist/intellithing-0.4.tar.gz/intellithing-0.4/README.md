# intellithing

An opensource project started by frasturated data scientists. INTELLITHING is an opensource library to reduce the amount of coding required for a successful finetuning of Large Language Models. 
